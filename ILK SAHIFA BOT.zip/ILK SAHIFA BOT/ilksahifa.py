from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
import asyncio
import logging
import os
from collections import deque
from dotenv import load_dotenv
from google.oauth2.service_account import Credentials
import gspread
import random
from aiogram.client.default import DefaultBotProperties

# === Configurations ===
load_dotenv("bottoken.env")

BOT_TOKEN = os.getenv("BOT_TOKEN")
ADMIN_ID = os.getenv("ADMIN_ID")
GOOGLE_SHEETS_CREDENTIALS = os.getenv("GOOGLE_SHEETS_CREDENTIALS")
SHEET_NAME = os.getenv("SHEET_NAME")
CHANNEL_ID = os.getenv("CHANNEL_ID")

# === Tekshirish ===
if not BOT_TOKEN:
    raise ValueError("❌ BOT_TOKEN aniqlanmadi! Iltimos, tokenni to‘g‘ri sozlang.")
if not ADMIN_ID:
    raise ValueError("❌ ADMIN_ID aniqlanmadi! Admin ID-ni kiriting.")
if not GOOGLE_SHEETS_CREDENTIALS:
    raise ValueError("❌ GOOGLE_SHEETS_CREDENTIALS aniqlanmadi! JSON fayl yo‘q.")
if not SHEET_NAME:
    raise ValueError("❌ SHEET_NAME aniqlanmadi! Google Sheets nomini kiriting.")
if not CHANNEL_ID:
    raise ValueError("❌ CHANNEL_ID aniqlanmadi! Kanal ID-ni kiriting.")

# === Bot va Dispatcher ===
bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode="HTML"))
dp = Dispatcher()

# === Global variables ===
yuborilgan_sozlar = deque(maxlen=100)
yuborilgan_soni = 0

# === Google Sheets'ga ulanish ===
SCOPES = [
    "https://www.googleapis.com/auth/spreadsheets.readonly",
    "https://www.googleapis.com/auth/drive.readonly"
]
credentials = Credentials.from_service_account_file(GOOGLE_SHEETS_CREDENTIALS, scopes=SCOPES)
gc = gspread.authorize(credentials)

# === Logging ===
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

# === Hikmatlarni olish funksiyasi ===
def get_hikmat():
    """Google Sheets'dan hikmatli so‘z olish."""
    try:
        sheet = gc.open(SHEET_NAME).sheet1
        all_hikmatlar = sheet.get_all_values()[1:]

        if not all_hikmatlar:
            logging.warning("⚠ Google Sheets bo‘sh.")
            return None

        for _ in range(5):  # Maksimal 5 martagacha urinib ko‘ramiz
            hikmat = random.choice(all_hikmatlar)
            if hikmat and "".join(hikmat) not in yuborilgan_sozlar:
                yuborilgan_sozlar.append("".join(hikmat))
                return hikmat
        logging.warning("⚠ Hikmatli so‘zlar topilmadi.")
        return None
    except Exception as e:
        logging.error(f"⚠ Google Sheets bilan bog‘lanishda xatolik: {e}")
        return None

# === Bot Buyruqlari ===
@dp.message(Command("start"))
async def start_command(message: types.Message):
    await message.answer("👋 <b>Assalomu alaykum!</b>\n Hikmatli so‘zlarni kanalga yuborish uchun /hikmat buyrug‘ini yuboring.\n\n /help yordam")

@dp.message(Command("help"))
async def help_command(message: types.Message):
    help_text = (
        "📌 <b>Buyruqlar ro‘yxati:</b>\n"
        "✅ /start - Botni boshlash\n"
        "✅ /hikmat - Hikmatli so‘zlarni kanalga yuborish\n"
        "✅ /statistika - Nechta hikmatli so‘zlar yuborilganligini ko‘rish\n"
    )
    await message.answer(help_text)

@dp.message(Command("statistika"))
async def statistika_command(message: types.Message):
    await message.answer(f"📊 Hozirgacha yuborilgan hikmatlar soni: {yuborilgan_soni}")

@dp.message(Command("hikmat"))
async def manual_send_hikmat(message: types.Message):
    hikmat = get_hikmat()
    if not hikmat:
        await message.answer("⚠❌ Hikmatli so‘zlar tugadi yoki Google Sheets bo‘sh!")
        return
    await message.answer("✅ Hikmatli so‘zlar kanalga yuborildi!")
    await send_hikmat()

async def send_hikmat():
    global yuborilgan_soni
    hikmat = get_hikmat()
    if not hikmat:
        return
    await bot.send_message(CHANNEL_ID, f"🇺🇿 {hikmat[0]}\n#uzbek\n@ilksahifa")
    await bot.send_message(CHANNEL_ID, f"🇹🇷 {hikmat[1]}\n#türkçe\n@ilksahifa")
    await bot.send_message(CHANNEL_ID, f"🇷🇺 {hikmat[2]}\n#русский\n@ilksahifa")
    yuborilgan_soni += 1

# === Hikmatli so‘zlarni har 12 soatda yuborish ===
async def schedule_hikmat():
    while True:
        try:
            await send_hikmat()
            logging.info("✅ Hikmatli so‘z yuborildi!")
        except Exception as e:
            logging.error(f"❌ Hikmat yuborishda xatolik: {e}")
        await asyncio.sleep(43200)  # 12 soat (43200 sekund)

# === Botni Ishga Tushirish ===
async def main():
    logging.info("🚀 Bot ishga tushmoqda...")
    try:
        asyncio.create_task(schedule_hikmat())
        await dp.start_polling(bot)
    finally:
        await bot.session.close()

if __name__ == "__main__":
    asyncio.run(main())
